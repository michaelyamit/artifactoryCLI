from setuptools import setup

setup(
    name='amitmichaelyArtCLI',
    version='1.0.0',
    script=['artcli']
)